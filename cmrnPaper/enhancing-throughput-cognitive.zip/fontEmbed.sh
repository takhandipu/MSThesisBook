pdf2ps file.pdf file.ps
ps2pdf14 -dPDFSETTINGS=/prepress -dEmbedAllFonts=true file.ps file.pdf
