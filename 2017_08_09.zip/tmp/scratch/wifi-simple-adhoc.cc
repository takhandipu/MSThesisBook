/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2009 The Boeing Company
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

// 
// This script configures two nodes on an 802.11b physical layer, with
// 802.11b NICs in adhoc mode, and by default, sends one packet of 1000 
// (application) bytes to the other node.  The physical layer is configured
// to receive at a fixed RSS (regardless of the distance and transmit
// power); therefore, changing position of the nodes has no effect. 
//
// There are a number of command-line options available to control
// the default behavior.  The list of available command-line options
// can be listed with the following command:
// ./waf --run "wifi-simple-adhoc --help"
//
// For instance, for this configuration, the physical layer will
// stop successfully receiving packets when rss drops below -97 dBm.
// To see this effect, try running:
//
// ./waf --run "wifi-simple-adhoc --rss=-97 --numPackets=20"
// ./waf --run "wifi-simple-adhoc --rss=-98 --numPackets=20"
// ./waf --run "wifi-simple-adhoc --rss=-99 --numPackets=20"
//
// Note that all ns-3 attributes (not just the ones exposed in the below
// script) can be changed at command line; see the documentation.
//
// This script can also be helpful to put the Wifi layer into verbose
// logging mode; this command will turn on all wifi logging:
// 
// ./waf --run "wifi-simple-adhoc --verbose=1"
//
// When you are done, you will notice two pcap trace files in your directory.
// If you have tcpdump installed, you can try this:
//
// tcpdump -r wifi-simple-adhoc-0-0.pcap -nn -tt
//

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/mobility-module.h"
#include "ns3/config-store-module.h"
#include "ns3/wifi-module.h"
#include "ns3/internet-module.h"

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <map>

NS_LOG_COMPONENT_DEFINE ("WifiSimpleAdhoc");

using namespace ns3;

using namespace std;

int x = 0;

void ReceivePacket (Ptr<Socket> socket)
{
  //NS_LOG_UNCOND ("Received one packet!");
  x += 1;
}

static void GenerateTraffic (Ptr<Socket> socket, uint32_t pktSize, 
                             uint32_t pktCount, Time pktInterval )
{
  //cout<<"Packet"<<endl;
  //if (pktCount > 0)
    //{
      socket->Send (Create<Packet> (pktSize));
      Simulator::Schedule (pktInterval, &GenerateTraffic, 
                           socket, pktSize,pktCount, pktInterval);
    //}
  //else
    //{
      //socket->Close ();
    //}
}

typedef Ptr<YansWifiChannel> channelPointer;
typedef Ptr<WifiNetDevice> devicePointer;
vector<channelPointer> createdChannels;
Ptr<UniformRandomVariable> myUniformRNG = CreateObject<UniformRandomVariable> ();
vector<double> records;

Ptr<UniformRandomVariable> myExpoRNG = CreateObject<UniformRandomVariable> ();

static void changeChannel ( vector<devicePointer> devices[], uint32_t numRadios)
{
  for (uint32_t iterateVariable = 0; iterateVariable < numRadios; iterateVariable++)
  {
    vector<devicePointer> currentDevice = devices[iterateVariable];
    for(uint32_t anotherVariable = 0; anotherVariable < currentDevice.size(); anotherVariable++)
    {
      devicePointer device = currentDevice[anotherVariable];
      Ptr<WifiPhy> phy = device -> GetPhy ();
      uint32_t rand = myUniformRNG -> GetInteger ();
      phy -> SetChannelNumber (createdChannels[rand] -> GetId ());
      device -> channelId = rand;
    }
  }
  //cout<<"Changed"<<endl;
  double value = (myExpoRNG->GetValue());
  //cout<<"Change "<<value<<endl;
  Simulator::Schedule (Seconds(1.0+value), changeChannel, devices, numRadios);
}

static void readChannelTrace ( vector<devicePointer> devices[], uint32_t numRadios)
{
  map<uint32_t, uint32_t> channelTrace;
  for (uint32_t iterateVariable = 0; iterateVariable < numRadios; iterateVariable++)
  {
    vector<devicePointer> currentDevice = devices[iterateVariable];
    for(uint32_t anotherVariable = 0; anotherVariable < currentDevice.size(); anotherVariable++)
    {
      devicePointer device = currentDevice[anotherVariable];
      Ptr<WifiPhy> phy = device -> GetPhy ();
      uint32_t channelId = phy -> GetChannelNumber ();
      //uint32_t channelId = device -> channelId;
      if(phy->IsStateIdle() || phy->IsStateSwitching() || phy->IsStateSensing() )continue;
      if(channelTrace[channelId]) {
        channelTrace[channelId]++;
      } else {
        channelTrace[channelId] = 1;
      }
    }
  }
  double sum=0;
  uint32_t count=0;
  for (map<uint32_t, uint32_t>::const_iterator iterateVariable = channelTrace.begin (); iterateVariable != channelTrace.end (); ++iterateVariable)
  {
    count+=1;
    sum+=iterateVariable->second;
  }
  if(count>0)records.push_back(sum/count);
  else records.push_back(0);
  double value = (myExpoRNG->GetValue());
  //cout<<"Read "<<value<<endl;
  Simulator::Schedule (Seconds(2.0+value), readChannelTrace, devices, numRadios);
}

NetDeviceContainer transformNetDeviceContainer(vector<devicePointer> devices)
{
  NetDeviceContainer returnDevices;
  for(uint32_t iterateVariable = 0; iterateVariable < devices.size(); iterateVariable++)
  {
    returnDevices.Add(devices[iterateVariable]);
  }
  return returnDevices;
}

void createChannels(uint32_t numChannels, YansWifiChannelHelper wifiChannel)
{
  for(uint32_t iterateVariable = 0; iterateVariable < numChannels; iterateVariable++) {
    channelPointer channel = wifiChannel.Create ();
    createdChannels.push_back(channel);
  }
}


int main (int argc, char *argv[])
{
  string phyMode ("DsssRate1Mbps");
  double rss = -80;  // -dBm
  uint32_t packetSize = 1024; // bytes
  uint32_t numPackets = 1;
  double interval = 0.02; // seconds
  bool verbose = false;
  uint32_t numRadios = 1;
  uint32_t numChannels = 1;
  
  myExpoRNG->SetAttribute ("Min", DoubleValue (1.0));
  myExpoRNG->SetAttribute ("Max", DoubleValue (5.0));

  CommandLine cmd;

  cmd.AddValue ("phyMode", "Wifi Phy mode", phyMode);
  cmd.AddValue ("rss", "received signal strength", rss);
  cmd.AddValue ("packetSize", "size of application packet sent", packetSize);
  cmd.AddValue ("numPackets", "number of packets generated", numPackets);
  cmd.AddValue ("interval", "interval (seconds) between packets", interval);
  cmd.AddValue ("verbose", "turn on all WifiNetDevice log components", verbose);
  cmd.AddValue ("numRadios", "number of radios per node", numRadios);
  cmd.AddValue ("numChannels", "number of wireless channels", numChannels);

  cmd.Parse (argc, argv);
  // Convert to time object
  Time interPacketInterval = Seconds (interval);

  // disable fragmentation for frames below 2200 bytes
  Config::SetDefault ("ns3::WifiRemoteStationManager::FragmentationThreshold", StringValue ("2200"));
  // turn off RTS/CTS for frames below 2200 bytes
  Config::SetDefault ("ns3::WifiRemoteStationManager::RtsCtsThreshold", StringValue ("0"));
  // Fix non-unicast data rate to be the same as that of unicast
  Config::SetDefault ("ns3::WifiRemoteStationManager::NonUnicastMode", 
                      StringValue (phyMode));

  NodeContainer c;
  c.Create (5);

  // The below set of helpers will help us to put together the wifi NICs we want
  WifiHelper wifi;
  if (verbose)
    {
      wifi.EnableLogComponents ();  // Turn on all Wifi logging
    }
  wifi.SetStandard (WIFI_PHY_STANDARD_80211b);

  YansWifiPhyHelper wifiPhy =  YansWifiPhyHelper::Default ();
  // This is one parameter that matters when using FixedRssLossModel
  // set it to zero; otherwise, gain will be added
  wifiPhy.Set ("RxGain", DoubleValue (0.0) ); 
  // ns-3 supports RadioTap and Prism tracing extensions for 802.11b
  wifiPhy.SetPcapDataLinkType (YansWifiPhyHelper::DLT_IEEE802_11_RADIO); 

  YansWifiChannelHelper wifiChannel;
  wifiChannel.SetPropagationDelay ("ns3::ConstantSpeedPropagationDelayModel");
  // The below FixedRssLossModel will cause the rss to be fixed regardless
  // of the distance between the two stations, and the transmit power
  wifiChannel.AddPropagationLoss ("ns3::FixedRssLossModel","Rss",DoubleValue (rss));
  //Ptr<YansWifiChannel> yansWifiChannel = wifiChannel.Create ();
  //wifiPhy.SetChannel ( yansWifiChannel );
  createChannels (numChannels, wifiChannel);
  myUniformRNG->SetAttribute ("Min", DoubleValue (0));
  myUniformRNG->SetAttribute ("Max", DoubleValue(numChannels-1));
  wifiPhy.SetChannel ( createdChannels[0] );

  // Add a non-QoS upper mac, and disable rate control
  NqosWifiMacHelper wifiMac = NqosWifiMacHelper::Default ();
  wifi.SetRemoteStationManager ("ns3::ConstantRateWifiManager",
                                "DataMode",StringValue (phyMode),
                                "ControlMode",StringValue (phyMode));
  // Set it to adhoc mode
  wifiMac.SetType ("ns3::AdhocWifiMac");
  vector<devicePointer> devices[numRadios];// = wifi.Install (wifiPhy, wifiMac, c);
  for(uint32_t iterateVariable = 0; iterateVariable < numRadios; iterateVariable++)
  {
    devices[iterateVariable] = wifi.myInstall (wifiPhy, wifiMac, c);
  }
  NetDeviceContainer netDevices = transformNetDeviceContainer(devices[0]);

  // Note that with FixedRssLossModel, the positions below are not 
  // used for received signal strength. 
  MobilityHelper mobility;
  Ptr<ListPositionAllocator> positionAlloc = CreateObject<ListPositionAllocator> ();
  positionAlloc->Add (Vector (0.0, 0.0, 0.0));
  positionAlloc->Add (Vector (5.0, 0.0, 0.0));
  mobility.SetPositionAllocator (positionAlloc);
  mobility.SetMobilityModel ("ns3::ConstantPositionMobilityModel");
  mobility.Install (c);

  InternetStackHelper internet;
  internet.Install (c);

  Ipv4AddressHelper ipv4;
  NS_LOG_INFO ("Assign IP Addresses.");
  ipv4.SetBase ("10.1.1.0", "255.255.255.0");
  Ipv4InterfaceContainer i = ipv4.Assign (netDevices);
  //Ipv4InterfaceContainer i[numRadios];// = ipv4.Assign (devices[0]);
  /*for(uint32_t iterateVariable = 0; iterateVariable < numRadios; iterateVariable++)
  {
    i[iterateVariable] = ipv4.Assign (devices[iterateVariable]);
  }*/

  TypeId tid = TypeId::LookupByName ("ns3::UdpSocketFactory");
  Ptr<Socket> recvSink = Socket::CreateSocket (c.Get (0), tid);
  InetSocketAddress local = InetSocketAddress (Ipv4Address::GetAny (), 80);
  recvSink->Bind (local);
  recvSink->SetRecvCallback (MakeCallback (&ReceivePacket));

  Ptr<Socket> source = Socket::CreateSocket (c.Get (1), tid);
  InetSocketAddress remote = InetSocketAddress (Ipv4Address ("255.255.255.255"), 80);
  source->SetAllowBroadcast (true);
  source->Connect (remote);

  // Tracing
  wifiPhy.EnablePcap ("wifi-simple-adhoc", netDevices);
  /*for(uint32_t iterateVariable = 0; iterateVariable < numRadios; iterateVariable++)
  {
    wifiPhy.EnablePcap ("wifi-simple-adhoc", devices[iterateVariable]);
  }*/
  
  // Output what we are doing
  //NS_LOG_UNCOND ("Testing " << numPackets  << " packets sent with receiver rss " << rss );

  Simulator::ScheduleWithContext (source->GetNode ()->GetId (),
                                  Seconds (1.0), &GenerateTraffic, 
                                  source, packetSize, numPackets, interPacketInterval);
  Simulator::Schedule (Seconds(0.0), &changeChannel, devices, numRadios);
  Simulator::Schedule (Seconds(2.0), &readChannelTrace, devices, numRadios);
  Simulator::Stop (Seconds (101.0));
  Simulator::Run ();
  Simulator::Destroy ();
  //NS_LOG_UNCOND("Total Packets received "<<x);
  /*for(uint32_t iterateVariable = 0; iterateVariable < numChannels; iterateVariable ++){
    channelPointer iterateChannel = createdChannels[iterateVariable];
    NS_LOG_UNCOND("Total " << iterateChannel -> GetNDevices () <<" radios are connected in the channel "<< iterateChannel -> GetId () );
  }*/
  double sum = 0.0;
  uint32_t count = 0;
  for(uint32_t iterateVariable = 0; iterateVariable < records.size(); iterateVariable++)
  {
    sum+=records[iterateVariable];
    count+=1;
    //cout<<records[iterateVariable]<<endl;
  }
  cout<<numRadios<<" "<<sum/count<<endl;
  return 0;
}

